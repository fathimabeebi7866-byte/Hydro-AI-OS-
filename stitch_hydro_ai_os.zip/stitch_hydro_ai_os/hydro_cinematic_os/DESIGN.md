---
name: Hydro-Cinematic OS
colors:
  surface: '#0c1324'
  surface-dim: '#0c1324'
  surface-bright: '#33394c'
  surface-container-lowest: '#070d1f'
  surface-container-low: '#151b2d'
  surface-container: '#191f31'
  surface-container-high: '#23293c'
  surface-container-highest: '#2e3447'
  on-surface: '#dce1fb'
  on-surface-variant: '#bbc9cd'
  inverse-surface: '#dce1fb'
  inverse-on-surface: '#2a3043'
  outline: '#859397'
  outline-variant: '#3c494c'
  surface-tint: '#2fd9f4'
  primary: '#8aebff'
  on-primary: '#00363e'
  primary-container: '#22d3ee'
  on-primary-container: '#005763'
  inverse-primary: '#006877'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#d2ddf5'
  on-tertiary: '#263143'
  tertiary-container: '#b6c1d9'
  on-tertiary-container: '#444f63'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#a2eeff'
  primary-fixed-dim: '#2fd9f4'
  on-primary-fixed: '#001f25'
  on-primary-fixed-variant: '#004e5a'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#d8e3fb'
  tertiary-fixed-dim: '#bcc7de'
  on-tertiary-fixed: '#111c2d'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#0c1324'
  on-background: '#dce1fb'
  surface-variant: '#2e3447'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.15em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.4'
spacing:
  unit: 4px
  gutter: 24px
  margin: 40px
  panel-padding: 16px
  container-max-width: 1440px
---

## Brand & Style

The design system is centered on a "Futuristic OS" aesthetic, evoking the immersive, high-stakes environment of a cinematic AI command center. It targets power users and tech enthusiasts who demand an interface that feels like a physical manifestation of digital intelligence. 

The visual style is **Hyper-Glassmorphism** combined with **Technological Minimalism**. It utilizes deep spatial depth, holographic projections, and high-energy neon light paths to guide the user's eye. The emotional response is one of total control, precision, and "living in the future." Every interaction should feel like a pulse of energy through a liquid-crystal circuit.

## Colors

The palette is anchored in a "Void Black" (#020617) to provide infinite perceived depth.
- **Primary (Neon Cyan):** Used for active data streams, primary calls to action, and "safe" system status. It should be accompanied by a 0 0 15px glow effect.
- **Secondary (Electric Purple):** Used for advanced AI functions, encryption states, and secondary visual interest to prevent the UI from feeling monochromatic.
- **Accents:** Use a subtle Slate (#1e293b) for structural elements that should recede into the background.
- **Status:** Critical alerts should bypass the palette for a High-Intensity Red (#f43f5e) to ensure immediate cognitive recognition.

## Typography

This design system utilizes a dual-font approach to balance technical precision with readability. 

**JetBrains Mono** is used for all "System Metadata," headers, and interactive labels. It reinforces the OS/Coding aesthetic. Use uppercase for labels to create a "readout" feel.

**Inter** is used for dense body text and descriptions. Its neutrality ensures that even in a data-heavy "Tron-like" environment, content remains legible and professional.

Text rendering should utilize `antialiased` properties. For headlines, apply a very subtle text-shadow of the primary color at 10% opacity to simulate a glowing phosphor screen.

## Layout & Spacing

The layout follows a **Rigid Grid with Fluid Overlays**. 
- **Grid:** Use a 12-column grid for the base layer.
- **Density:** High. Elements are packed tightly to simulate a cockpit or terminal, but separated by clear "light-pipe" borders.
- **Reflow:** On mobile, panels stack vertically, and complex data visualizations should switch to simplified summary cards.
- **Scanlines:** A global overlay of 1px horizontal lines at 3% opacity should be applied to the entire screen to maintain the "monitor" aesthetic.

## Elevation & Depth

Depth is achieved through **Z-Axis Layering** and **Luminance**, rather than traditional shadows.
1. **Level 0 (Background):** Deepest Black (#020617).
2. **Level 1 (Panels):** Glassmorphism. Background blur at 20px, 10% opacity white fill, and a 1px border at 20% primary color opacity.
3. **Level 2 (Active Elements):** High-intensity borders (Neon Cyan) with a localized outer glow (`box-shadow: 0 0 10px rgba(34, 211, 238, 0.4)`).
4. **Level 3 (Holographic Popovers):** Elements that appear to float above the "glass." These use 40% opacity backgrounds and animated "corner brackets" to define their space.

## Shapes

The shape language is **Aggressively Sharp**. 
- **Corners:** 0px radius for almost all containers to emphasize a military-grade, precision-engineered feel.
- **Angled Accents:** Use 45-degree chamfered corners for buttons and primary headers to evoke the "stealth fighter" aesthetic.
- **Dividers:** Instead of simple lines, use "Data-Lines" which consist of a 1px solid line ending in a small 4px square or a terminal dot.

## Components

### Buttons
- **Primary:** No fill. 1px Neon Cyan border. Text in Cyan. On hover: Cyan fill with Black text and a heavy outer glow.
- **Ghost:** No border. Text in Cyan. Corner brackets appear only on hover.

### Input Fields
- Underline-only style with a "blinking cursor" caret. When focused, the entire field glows subtly.

### Cards (Glass Panels)
- Must include a "System ID" in the top-right corner (e.g., `REF_0042`) in `label-caps` typography to reinforce the AI theme.
- Borders should be semi-transparent except for the corners, which are 100% opaque.

### Progress Bars
- Segmented blocks rather than a smooth fill. Active blocks should pulse with a Cyan-to-Purple gradient.

### Additional Components
- **Data Scanners:** An animated horizontal line that moves vertically across "loading" panels.
- **Status HUD:** A fixed-position corner element showing "System Uptime" and "Neural Load" (mock data) to fill the environment.