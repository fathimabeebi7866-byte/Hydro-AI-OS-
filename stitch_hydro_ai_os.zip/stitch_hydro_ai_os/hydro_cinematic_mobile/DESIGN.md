---
name: Hydro-Cinematic Mobile
colors:
  surface: '#111417'
  surface-dim: '#111417'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#191c1f'
  surface-container: '#1d2023'
  surface-container-high: '#282a2e'
  surface-container-highest: '#323539'
  on-surface: '#e1e2e7'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e1e2e7'
  inverse-on-surface: '#2e3134'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#9bcfda'
  on-secondary: '#00363e'
  secondary-container: '#154e57'
  on-secondary-container: '#8abdc8'
  tertiary: '#faf3ff'
  on-tertiary: '#3c0090'
  tertiary-container: '#e1d2ff'
  on-tertiary-container: '#7213ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#b7ebf6'
  secondary-fixed-dim: '#9bcfda'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#154e57'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d1bcff'
  on-tertiary-fixed: '#23005b'
  on-tertiary-fixed-variant: '#5700c9'
  background: '#111417'
  on-background: '#e1e2e7'
  surface-variant: '#323539'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-sm:
    fontFamily: Sora
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.08em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 1rem
  gutter-mobile: 1rem
  touch-target-min: 2.75rem
  stack-xs: 0.25rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 1.5rem
  stack-xl: 2rem
---

## Brand & Style
The design system evokes a high-tech, liquid-intelligence atmosphere tailored for high-density mobile displays. It targets a tech-forward audience that values depth, immersion, and precision.

The style is a fusion of **Glassmorphism** and **Modern Corporate**, optimized for the palm of the hand. It utilizes deep ebony voids and luminous cyan accents to create a "cinematic OS" feel. On mobile, this translates to heavy use of backdrop blurs, subtle glowing edges, and fluid transitions that mimic the surface of dark water. The goal is to make the interface feel like a premium, handheld holographic device.

## Colors
The palette is rooted in deep space blacks to maximize OLED efficiency and visual depth.

*   **Primary:** A vibrant "Electric Cyan" (#00F0FF) used for critical actions, active states, and glowing data points.
*   **Secondary:** "Deep Hydro" (#00414A), a muted teal used for secondary buttons and container strokes to maintain the underwater aesthetic.
*   **Tertiary:** "Neon Violet" (#7000FF), reserved for specialized alerts or rare high-priority interactions to provide a cinematic pop against the cyan.
*   **Neutral:** "Abyssal Black" (#05070A) serves as the base surface, ensuring high contrast for legibility.

## Typography
The typography system balances futuristic geometry with high readability. 

*   **Sora** provides the geometric, bold voice for headlines, echoing the tech-centric theme.
*   **Hanken Grotesk** is used for body copy to ensure clarity and professional polish at smaller scales.
*   **JetBrains Mono** is utilized for labels and data readouts, reinforcing the "system" and "code" aesthetic of a cinematic OS.

On mobile, display sizes are capped at 32px to prevent excessive wrapping. Line heights are slightly increased for body text to improve scanning on tall mobile screens.

## Layout & Spacing
The layout uses a **Fluid Grid** model optimized for narrow viewports. 

*   **Mobile (0-599px):** 4-column grid with 16px margins and 16px gutters.
*   **Tablet (600-904px):** 8-column grid with 32px margins.
*   **Touch Targets:** All interactive elements maintain a minimum area of 44x44pt (2.75rem) to ensure accessibility.

Spacing follows a strict 4px / 8px incremental scale. Vertical rhythm is prioritized, with "Stack" variables defining the distance between logical content blocks. Elements should favor full-bleed or "floating card" layouts to maximize real estate.

## Elevation & Depth
Depth is created through **Glassmorphism** and **Tonal Layering** rather than traditional drop shadows.

1.  **Base Layer:** Solid Abyssal Black (#05070A).
2.  **Surface Layer:** Semi-transparent (60% opacity) dark fills with a 20px backdrop blur.
3.  **Floating Elements:** Use a 1px inner border (Cyan at 20% opacity) to simulate a light-catching edge on glass.
4.  **Cinematic Glows:** Interactive elements (buttons, active toggles) use a soft Cyan outer glow (spread: 4px, blur: 12px, opacity: 0.3) instead of hard shadows. This simulates light emitting from the UI itself.

## Shapes
The design system utilizes **Rounded** shapes to soften the high-tech aesthetic, making the OS feel more organic and "liquid."

*   Standard components (Inputs, Buttons): 0.5rem (8px).
*   Large containers (Cards, Sheets): 1rem (16px).
*   Active indicators (Chips, Progress bars): Fully rounded (Pill).

Consistent corner radiuses are critical to maintaining the "engineered" feel of the system.

## Components
*   **Buttons:** Primary buttons are solid Cyan with black text. Secondary buttons use a Deep Hydro stroke with Cyan text. Mobile buttons must span the full width of their container or a minimum of 44px height.
*   **Input Fields:** Ghost-style inputs with a 1px bottom border and a subtle glass background. Focused states trigger a 1px Cyan glow across the entire border.
*   **Cards:** Glass-morphic containers with `backdrop-filter: blur(20px)`. Includes a top-left "technical label" in JetBrains Mono to identify the data type.
*   **Chips:** Pill-shaped with a 1px Cyan stroke. Active chips have a subtle inner glow.
*   **Lists:** High-density rows with 16px vertical padding. Use "Hydro" dividers (1px height, 10% Cyan opacity) that do not reach the edges of the screen.
*   **Glass Sheets:** Bottom sheets for mobile navigation use a 80% opacity Abyssal Black with a heavy blur and a 2px top handle for drag interaction.